import torch
from torch import nn
import torch.nn.functional as F
from torch.autograd import Variable

import math
import copy


class InputEmbeddings(nn.Module):
    """
    Embedded layer
    """

    def __init__(self, vocab_size, embedding_dim):
        super(InputEmbeddings, self).__init__()
        # Embedded layer vector dimension
        self.embedding_dim = embedding_dim
        # One vector for each word. Use a vector to represent a word
        self.embed = nn.Embedding(vocab_size, embedding_dim)

    def forward(self, x):
        # Dividing each dimension data of a vector by the square root of the dimension
        # similar to doing a normalization
        return self.embed(x) * math.sqrt(self.embedding_dim)


class PositionalEncoding(nn.Module):
    """
    Location information layer
    """

    def __init__(self, embedding_dim, dropout, max_len=5000):

        super(PositionalEncoding, self).__init__()
        # drop layer
        self.dropout = nn.Dropout(p=dropout)
        # Initialize final location information
        pe = torch.zeros(max_len, embedding_dim)
        # The position of specific words ranges from 0 to sentence length
        position = torch.arange(0.0, max_len).unsqueeze(1)  # shape : [max_len, 1]
        #
        div_term = torch.exp(
            torch.arange(0.0, embedding_dim, 2) * -(math.log(10000.0) / embedding_dim)
        )  # shape : [embedding_dim/2]

        # Get location information
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        # The final result is dimensionally compressed for subsequent calculation
        pe = pe.unsqueeze(0)
        # Set a constant in the memory, which can be written and read when the model is saved and loaded
        self.register_buffer("pe", pe)

    def forward(self, x):
        # Here is the final input of x+position information.
        # Each x has a position code. This ensures the difference of words in different positions
        x = x + Variable(self.pe[:, : x.size(1)], requires_grad=False)  # Embedding+PositionalEncoding
        return self.dropout(x)


def clones(module, N):
    # deep copy
    return nn.ModuleList([copy.deepcopy(module) for _ in range(N)])


def attention(query, key, value, mask=None, dropout=None):  # q,k,v:[batch, h, seq_len, d_k]
    """
    Attention layer
    The attention layer can be understood as a weighted layer, which is calculated and then weighted
    """
    # Find the dimension of query
    d_k = query.size(-1)
    # transpose
    scores = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(d_k) # Scoring mechanism [batch, h, seq_len, seq_len]
    # The function of mask is to record the position of words in sentences.
    # Use 1 and 0 to indicate whether there are words in this position
    if mask is not None:
        scores = scores.masked_fill(mask == 0, -1e9)
    # For the normalized score of the last dimension [batch, h, seq_len, seq_len]
    # In fact, it is a normalized operation
    p_attn = F.softmax(scores, dim=-1)
    # Check whether the incoming parameters need to be inactivated randomly
    if dropout is not None:
        p_attn = dropout(p_attn)
    # the return value is the multiplication of matrix in torch
    return torch.matmul(p_attn, value), p_attn  # [batch, h, seq_len, d_k]


class MultiHeadedAttention(nn.Module):
    """
    Implementation of multi-head attention model
    """

    def __init__(self, h, embedding_dim, dropout=0.1):
        super(MultiHeadedAttention, self).__init__()
        assert embedding_dim % h == 0
        # Divide embedding_dim into h dimensions
        self.d_k = embedding_dim // h
        # the number of heads
        self.h = h
        # Deep copy linear module
        self.linears = clones(nn.Linear(embedding_dim, embedding_dim), 4)
        # The attn variable is assigned the value of None before operation
        self.attn = None
        # Scale of drop
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, query, key, value, mask=None):  # q,k,v:[batch, seq_len, embedding_dim]
        # Whether mask is required
        if mask is not None:
            # Compress the data dimension of the mask
            mask = mask.unsqueeze(1)  # [batch, seq_len, 1]
        # Calculate the size of query
        nbatches = query.size(0)
        # 1) Batch perform all linear operations from embedding_dim=> h x d_k
        # [batch, seq_len, h, d_k] -> [batch, h, seq_len, d_k]
        query, key, value = [
            l(x).view(nbatches, -1, self.h, self.d_k).transpose(1, 2) for l, x in zip(self.linears, (query, key, value))
        ]
        # 2) Apply attention on all the projected vectors in batch.
        # Perform the attachment operation on all linear vectors
        x, self.attn = attention(
            query, key, value, mask=mask, dropout=self.dropout
        )  # x:[batch, h, seq_len, d_k], attn:[batch, h, seq_len, seq_len]

        # 3) "Concat" using a view and apply a final linear.
        # Connect all the linear results of the previous step
        x = x.transpose(1, 2).contiguous().view(nbatches, -1, self.h * self.d_k)  # [batch, seq_len, embedding_dim]
        return self.linears[-1](x)


class MyTransformerModel(nn.Module):
    def __init__(self, vocab_size, embedding_dim, p_drop, h, output_size):
        super(MyTransformerModel, self).__init__()
        # Initialize drop layer   random deactivation layer
        self.drop = nn.Dropout(p_drop)
        # Initialize input embedding layer
        self.embeddings = InputEmbeddings(vocab_size, embedding_dim)
        # Initialize location information layer
        self.position = PositionalEncoding(embedding_dim, p_drop)
        # Initialize multi-head attention layer
        self.attn = MultiHeadedAttention(h, embedding_dim)
        # Initialize normalization layer
        self.norm = nn.LayerNorm(embedding_dim)
        # Initialize linear layer
        self.linear = nn.Linear(embedding_dim, output_size)
        # Initialize all weights
        self.init_weights()

    def init_weights(self):
        # Initialize the range of weights
        initrange = 0.1
        # Initialize the offset of linear layer to 0
        self.linear.bias.data.zero_()
        # Initialize the w weight of the first linear layer within the specified range
        self.linear.weight.data.uniform_(-initrange, initrange)

    def forward(self, inputs, mask):  #[batch, seq_len]
        # 1. InputEmbedding [batch, seq_len, embedding_dim]
        embeded = self.embeddings(inputs)
        # 2.PostionalEncoding [batch, seq_len, embedding_dim]
        embeded = self.position(embeded)
        # The masking layer is used to record which position has words and which position is empty[batch,seq_len,1]
        mask = mask.unsqueeze(2)
        # 3.1. MultiHeadedAttention layer[batch, seq_len, embedding_dim]
        inp_attn = self.attn(embeded, embeded, embeded, mask)
        # 3.2. The layer normalizes the layer so that the weight parameters of the layer do not deviate too much LayerNorm
        inp_attn = self.norm(inp_attn + embeded)
        # 4.1. linear layer  First use the mask of masking record to remove the information without words
        # Return [batch, seq_len, embedding_dim]
        inp_attn = inp_attn * mask
        # 4.2. linear layer  this is equivalent to a combination of all words in a sentence return[batch, embedding_dim]
        h_avg = inp_attn.sum(1) / (mask.sum(1) + 1e-5)
        # 4.3. It is sent to the linear layer, which is the final output  return[batch, 1] -> [batch]
        return self.linear(h_avg).squeeze()
