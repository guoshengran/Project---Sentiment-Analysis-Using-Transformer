from flask import Flask, render_template
import hashlib
import string
from datetime import datetime, timedelta
import random

from flask import Flask, render_template, session
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from sqlalchemy import desc, or_
from wtforms import StringField, SubmitField, PasswordField
from wtforms.validators import DataRequired, Length, email, EqualTo
import scrapy
from scrapy.crawler import CrawlerProcess
from transformer_model import MyTransformerModel

app = Flask(__name__)


class Config(object):
    SQLALCHEMY_DATABASE_URI = "mysql://root:xyz@127.0.0.1:3306/final_project"
    # root is the username,
    # xyz is the password
    # sql_demo is the database name
    SQLALCHEMY_TRACK_MODIFICATIONS = True

    SECRET_KEY = "456ffgyg8t765r67r7"


app.config.from_object(Config)
db = SQLAlchemy(app)


class User(db.Model):
    __tablename__ = "user"
    ID = db.Column(db.Integer, primary_key=True, autoincrement=True)
    Name = db.Column(db.String(10), unique=True)
    Email = db.Column(db.String(35))
    Password = db.Column(db.String(16))

class RegisterForm(FlaskForm):
    user_name = StringField(label=u"user", validators=[DataRequired(message=u"This field must Filled"),
                                                       Length(min=1, max=10, message="The name is not correct"),
                                                       ])
    password = PasswordField(label=u"password",
                             validators=[Length(min=8, max=16, message="The length of password is not reasonable")])
    email = StringField(label=u"email", validators=[DataRequired(message=u"This field must Filled"),
                                                    email(message="The format of email is not correct")])
    confirm_pass = PasswordField(label=u"password",
                                 validators=[Length(min=8, max=16, message="The length of password is not reasonable"),
                                             EqualTo("password", message="The password is not consistent ")])
    submit = SubmitField(label=u"Save")


class LoginForm(FlaskForm):
    user_name = StringField(label=u"user", validators=[DataRequired(message=u"This field must Filled"),
                                                       Length(min=1, max=30, message="The name is not correct"),
                                                       ])
    password = PasswordField(label=u"password",
                             validators=[Length(min=8, max=16, message="The password is not correct")])


class BookReview(FlaskForm):
    user_text = StringField()

class Test(FlaskForm):
    user_name = StringField()

@app.route("/")
def index():
    return render_template('Home.html')

@app.route("/to_identity", methods=["GET","POST"])
def to_identity():
    return render_template('Identity.html')

@app.route("/to_home", methods=["GET","POST"])
def to_home():
    return render_template('Home.html')

@app.route("/to_register")
def to_register():
    form=RegisterForm()
    message=""
    return render_template('Register.html', message=message, form=form)


@app.route("/to_user", methods=["GET","POST"])
def to_user():
    return render_template('Login.html')

@app.route("/to_developer", methods=["GET","POST"])
def to_developer():
    return render_template('Developer_Login.html')

@app.route("/developer", methods=["GET","POST"])
def developer():
    return render_template('Developer.html')

@app.route("/login2", methods=["GET","POST"])
def login2():
    form = LoginForm()
    user = db.session.query(User).filter_by(Name=form.user_name.data).first()
    print(user)
    if user == None:
        print(123)
        message = {"message": "user name does not exist"}
        return message
    print(456)
    if user.password != form.password.data:
        message = {"message":"password is not correct"}
        return message
    abc = form.password.data + user.value
    sha1 = hashlib.sha1()
    sha1.update(abc.encode("utf-8"))
    real_pass = sha1.hexdigest()
    if real_pass != user.password:
        message = {"message": "Password is not correct",
                       "judge": False}
        return message
        session["name"] = form.user_name.data
        message = {"message": "Login successfully",
                   "judge": True}
        return message
    message = {"message": "Something Wrong"}
    return message

@app.route("/user", methods=["GET","POST"])
def user():
    return render_template("User.html",message="",message2="")

@app.route("/sentiment", methods=["GET","POST"])
def sentiment():
    form = BookReview()
    text = form.user_text.data
    text = text.split(" ")
    flag = 0
    if text == "":
        message2={"message":"Please enter a piece of book review"}
        return render_template("User.html",message = message2, message2="")
        # Tokenize the text input
    encoded_text = tokenizer.encode_plus(
        text,
        max_length=512,
        padding='max_length',
        truncation=True,
        return_attention_mask=True,
        return_tensors='pt'
    )

    input_ids = encoded_text['input_ids']
    attention_mask = encoded_text['attention_mask']
    # Move the input tensors to the specified device
    input_ids = encoded_text['input_ids']
    attention_mask = encoded_text['attention_mask']
    data = request.json
    text = data["text"]


    inputs = tokenizer(text, return_tensors="pt")

    outputs = model(**inputs)

    sentiment_id = torch.argmax(outputs.logits, dim=1)
    sentiment = "positive" if sentiment_id == 1 else "negative"

    response = {"sentiment": sentiment}
    return jsonify(response)

    # Make the prediction
    with torch.no_grad():
        logits = model(input_ids, attention_mask=attention_mask)[0]
        pred = torch.argmax(logits).item()

    with torch.no_grad():
        logits = model(input_ids, attention_mask=attention_mask)[0]
        pred = torch.argmax(logits).item()
    # Return the predicted sentiment
    sentiment = 'positive' if pred == 1 else 'negative'
    return jsonify({'sentiment': sentiment})
    message = {"message":text}
    message2 = {"message":session["text"]}

    return render_template("User.html",message=message,message2=message2)


@app.route("/register", methods=["GET","POST"])
def register():
    form = RegisterForm()
    if not form.validate_on_submit():
        person = db.session.query(User).filter_by(Name=form.user_name.data).all()
        for i in person:
            if i.Name.upper() == form.user_name.data.upper():
                message = "The user name has existed"
                return render_template("Register.html", message=message,form=form)
        if form.password.data != form.confirm_pass.data:
            message = "Password can not be consistent with Confirm Password"
            return render_template("Register.html", message=message, form=form)
        user = User(Name=form.user_name.data, Email=form.email.data, Password=form.password.data)
        db.session.add(user)
        db.session.commit()
        message = "Register successfully"
        return render_template("Register.html", message=message, form=form)
    message = "Something wrong"
    return render_template('Register.html', message=message, form=form)

@app.route("/dev_login", methods=["GET","POST"])
def dev_login():
    form = LoginForm()
    user = db.session.query(User).filter_by(Name=form.user_name.data).first()
    print(user)
    if user == None:
        message = {"message": "user name does not exist"}
        return message
    if user.password != form.password.data:
        message = {"message":"password is not correct"}
        return message
    # abc = form.password.data + user.value
    # sha1 = hashlib.sha1()
    # sha1.update(abc.encode("utf-8"))
    # real_pass = sha1.hexdigest()
    # if real_pass != user.password:
    #     message = {"message": "Password is not correct",
    #                    "judge": False}
    #     return message
    #     session["name"] = form.user_name.data
    #     message = {"message": "Login successfully",
    #                "judge": True}
    #     return message
    message = {"message": "Login successfully"}
    return message


@app.route("/data_crawling", methods=["GET","POST"])
def data_crawling():
    name = 'book_review_spider'
    start_urls = ['https://www.goodreads.com/book/show']

    parse(self, response):
    book_title = response.css('.bookTitle::text').get().strip()
    book_author = response.css('.authorName span::text').get().strip()
    review_blocks = response.css('.review')

    for review_block in review_blocks:
        review_text = review_block.css('.readable::text').get().strip()
        review_rating = review_block.css('.staticStars .value::text').get().strip()
        review_author = review_block.css('.user a::text').get().strip()
        review_date = review_block.css('.reviewDate span::text').get().strip()
        yield {
            'book_title': book_title,
            'book_author': book_author,
            'review_text': review_text,
            'review_rating': review_rating,
            'review_author': review_author,
            'review_date': review_date
        }
    next_page_url = response.css('a.next_page::attr(href)').get()
    if next_page_url is not None:
        yield response.follow(next_page_url, callback=self.parse)
    List=[]
    for text in review_blocks:
        if "0" in text:
            signal = "negative"
        else:
            signal = "positive"
        message = {"text":text,"sign":signal}
        List.append(message)
    return render_template("Developer.html",list=List,message="")

def evaluate(text):
    input_ids = torch.tensor(tokenizer.encode(text, add_special_tokens=True)).unsqueeze(0)
    outputs = model(input_ids)
    logits = outputs[0]
    prob = torch.softmax(logits, dim=1).detach().numpy()
    return prob[0][1]

@app.route("/deploy", methods=["GET","POST"])
def deploy():
    data = pd.read_csv('book_review_dataset.csv')

    # Extract review text and sentiment labels
    reviews = data['review_text'].tolist()
    labels = data['sentiment'].tolist()

    # Convert labels to numerical values (0 for negative, 1 for positive)
    labels = np.array([0 if label == 'negative' else 1 for label in labels])

    # Define evaluation function
    # Initialize variables for accuracy calculation
    total_correct = 0
    total_predictions = 0

    # Loop through reviews and labels
    for review, label in zip(reviews, labels):
        # Tokenize review
        inputs = tokenizer(review, padding=True, truncation=True, return_tensors='pt')
        inputs = {key: val.to(device) for key, val in inputs.items()}

        # Get model prediction
        output = model(**inputs)[0]
        _, prediction = torch.max(output, dim=1)

        # Update accuracy calculation variables
        total_predictions += 1
        if prediction == label:
            total_correct += 1

    # Calculate accuracy
    correct = 0
    for i in range(len(data)):
        text = data['text'][i]
        label = data['label'][i]
        prob = evaluate(text)
        pred = int(prob > 0.5)
        if pred == label:
            correct += 1

    accuracy = correct / len(data)
    accuracy = total_correct / total_predictions
    return render_template("Developer.html", message=message)

@app.route("/model1", methods=["GET","POST"])
def model1():
    text="(Transformer)"
    message={"message":text}
    session["text"] = text
    return render_template("User.html", message="", message2=message)


@app.route("/model2", methods=["GET","POST"])
def model2():
    text="(CNN)"
    message={"message":text}
    session["text"] = text
    return render_template("User.html", message="", message2=message)

@app.route("/model3", methods=["GET","POST"])
def model3():
    text="(LSTM)"
    message={"message":text}
    session["text"] = text
    return render_template("User.html", message="", message2=message)



if __name__ == '__main__':
    app.run(debug=True)
