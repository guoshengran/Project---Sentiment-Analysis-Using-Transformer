import os
import json
import scrapy
from scrapy.crawler import CrawlerProcess
from flask import Flask, request, jsonify

# Set up Flask app
app = Flask(__name__)

# Define Spider for Goodreads reviews
class GoodreadsSpider(scrapy.Spider):
    name = 'goodreads'
    start_urls = ['https://www.goodreads.com/book/show/63271.The_Hobbit']

    def parse(self, response):
        # Extract book title and author name
        title = response.css('h1#bookTitle::text').get().strip()
        author = response.css('a.authorName span::text').get().strip()

        # Extract review text and rating for each review
        reviews = []
        for review in response.css('div.review'):
            text = review.css('div.text::text').get().strip()
            rating = review.css('span.rating-static::attr(title)').get().strip()
            reviews.append({'text': text, 'rating': rating})

        # Store data in a dictionary and return
        data = {'title': title, 'author': author, 'reviews': reviews}
        yield data

# Set up Scrapy pipeline to store data in JSON file
class JsonWriterPipeline:
    def open_spider(self, spider):
        self.file = open('book_reviews.json', 'w')
        self.file.write('[')

    def close_spider(self, spider):
        self.file.write(']')
        self.file.close()

    def process_item(self, item, spider):
        line = json.dumps(item) + ',\n'
        self.file.write(line)
        return item

# Set up Scrapy settings
settings = {
    'ITEM_PIPELINES': {'__main__.JsonWriterPipeline': 1},
    'FEED_FORMAT': 'json',
    'FEED_URI': 'book_reviews.json',
    'LOG_LEVEL': 'INFO'
}

# Define Flask route to start scraping and return data
@app.route('/scrape', methods=['POST'])
def scrape():
    # Get book URL from request data
    book_url = request.json['url']

    # Set up Scrapy process and start spider
    process = CrawlerProcess(settings)
    process.crawl(GoodreadsSpider, start_urls=[book_url])
    process.start()

    # Load data from JSON file and delete file
    with open('book_reviews.json') as f:
        data = json.load(f)
    os.remove('book_reviews.json')

    # Return data as JSON response
    return jsonify(data)

if __name__ == '__main__':
    # Run Flask app
    app.run(debug=True)