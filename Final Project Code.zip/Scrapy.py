import scrapy
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from goodreads_scraper.items import BookReviewItem

class BookReviewsSpider(CrawlSpider):
    name = 'book_reviews'
    allowed_domains = ['goodreads.com']
    start_urls = ['https://www.goodreads.com/book/show/']
    rules = [
        Rule(LinkExtractor(allow=r'/book/show/\d+-\w+'), callback='parse_book_reviews'),
        Rule(LinkExtractor(allow=r'/review/show/\d+'), callback='parse_review', follow=True)
    ]

    def parse_book_reviews(self, response):
        # Extract book title and author
        title = response.css('h1#bookTitle::text').get().strip()
        author = response.css('div#bookAuthors > span[itemprop="author"] > a > span[itemprop="name"]::text').get()

        # Follow link to first page of reviews
        reviews_url = response.url + '/reviews'
        yield scrapy.Request(reviews_url, callback=self.parse_reviews)

    def parse_reviews(self, response):
        # Follow links to individual reviews
        review_links = response.css('a[href*="/review/show/"]::attr(href)').getall()
        for link in review_links:
            yield scrapy.Request(link, callback=self.parse_review)

        # Follow link to next page of reviews
        next_page_url = response.css('a.next_page::attr(href)').get()
        if next_page_url:
            yield scrapy.Request(next_page_url, callback=self.parse_reviews)

    def parse_review(self, response):
        # Extract review text and sentiment
        review_text = response.css('div.reviewText > span ::text').getall()
        review_text = ' '.join(review_text).strip()
        rating = response.css('div.reviewHeader > span.staticStars > span.p10::attr(class)').get()
        if 'oneStar' in rating or 'twoStar' in rating or 'threeStar' in rating:
            sentiment = 'negative'
        else:
            sentiment = 'positive'

        # Extract book title and author
        title = response.css('h1.bookTitle > span[itemprop="name"]::text').get().strip()
        author = response.css('div.bookAuthor > span[itemprop="name"]::text').get()

        # Create and return BookReviewItem
        item = BookReviewItem()
        item['title'] = title
        item['author'] = author
        item['review_text'] = review_text
        item['sentiment'] = sentiment
        yield item