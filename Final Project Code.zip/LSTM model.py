import torch
import torch.nn as nn
import torch
import torch.nn as nn
import torch.optim as optim
from torchtext.datasets import text_classification
from torchtext.data.utils import ngrams_iterator
from torchtext.data.utils import get_tokenizer
from torchtext.vocab import build_vocab_from_iterator
from torchtext.datasets.text_classification import TextClassificationDataset
from torch.utils.data import DataLoader
from typing import Tuple
import os
import io
import requests

input_path = "D:/Project 2/sentiment_analysis_eng/static/raw_data/GoodReads_Dataset_Raw.csv"

class LSTMClassifier(nn.Module):
    def __init__(self, vocab_size, embed_dim, hidden_size, num_classes, num_layers=1, dropout=0.5):
        super(LSTMClassifier, self).__init__()
        self.vocab_size = vocab_size
        self.embed_dim = embed_dim
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.num_classes = num_classes

        # Embedding layer
        self.embedding = nn.Embedding(self.vocab_size, self.embed_dim)

        # LSTM layer
        self.lstm = nn.LSTM(self.embed_dim, self.hidden_size, num_layers=self.num_layers,
                            batch_first=True, dropout=dropout)

        # Dropout layer
        self.dropout = nn.Dropout(dropout)

        # Output layer
        self.fc = nn.Linear(self.hidden_size, self.num_classes)

    def forward(self, x):
        # Input x is a tensor of shape (batch_size, seq_len)
        embedded = self.embedding(x)  # (batch_size, seq_len, embed_dim)
        lstm_output, _ = self.lstm(embedded)  # (batch_size, seq_len, hidden_size)
        lstm_output = lstm_output.mean(dim=1)  # (batch_size, hidden_size)
        lstm_output = self.dropout(lstm_output)
        logits = self.fc(lstm_output)  # (batch_size, num_classes)
        return logits

    model = LSTMClassifier(vocab_size=10000, embed_dim=128, hidden_size=256, num_classes=2, num_layers=1, dropout=0.5)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss()

    for epoch in range(10):
        for batch in dataloader:
            x, y = batch
            logits = model(x)
            loss = criterion(logits, y)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

train_iter = []
test_iter = []
for name in ['pos', 'neg']:
    filename = f'./txt_sentoken/{name}.txt'
    with z.open(filename) as f:
        if name == 'pos':
            for line in f:
                train_iter.append((line.decode("utf-8"), 1))
        else:
            for line in f:
                train_iter.append((line.decode("utf-8"), 0))

    filename = f'./txt_sentoken/{name}.txt'
    with z.open(filename) as f:
        if name == 'pos':
            for line in f:
                test_iter.append((line.decode("utf-8"), 1))
        else:
            for line in f:
                test_iter.append((line.decode("utf-8"), 0))

NGRAMS = 2
import os
tokenizer = get_tokenizer('basic_english')
train_data = []
for (text, label) in train_iter:

    tokens = tokenizer(text)
    tokens = [int(hash(token) % 1000000) for token in tokens]
    tokens = list(ngrams_iterator(tokens, NGRAMS))
    train_data.append((tokens, label))
VOCAB_SIZE = 10000
vocab = build_vocab_from_iterator(
    [tokens for (tokens, _) in train_data],
    specials=["<unk>"],
    special_first=True,
    max_size=VOCAB_SIZE)

text_pipeline = lambda x: [vocab[token] for token in x]
label_pipeline = lambda x: int(x)
class train:

    train_dataset = TextClassificationDataset(
    [(text_pipeline(tokens), label_pipeline(label)) for (tokens, label) in train_data])

    train_dataset, test_dataset = train_dataset.split(split_ratio=0.7)
    for epoch in range(10):
    running_loss = 0.0
    running_corrects = 0
    model.train()
    for batch in train_iter:
        optimizer.zero_grad()
    text, labels = batch.text, batch.label
    outputs = model(text).squeeze(1)
    loss = criterion(outputs, labels)
    loss.backward()
    optimizer.step()
