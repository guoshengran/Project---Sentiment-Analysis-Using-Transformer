 window.addEventListener('load',() => {

            alert(123);
            let request = new XMLHttpRequest();
            request.open("POST", "http://127.0.0.1:5000/login2");
            request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            let user_name = document.getElementById("email").value;
            let password = document.getElementById("password").value;
            alert(123);
            if(user_name == "" || password=="")
            {
               window.alert("user name or password can not be empty");
            }
            else{
               let data = "user_name=" + user_name
                + "&password=" + password;
               request.send(data);
               request.onreadystatechange = function () {
                  alert("Login successfully");
                  setTimeout(() => {
                        window.location.href = 'http://127.0.0.1:5000/user';
                  }, 200)
               }

               }


           }



 }