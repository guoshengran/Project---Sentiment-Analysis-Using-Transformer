import copy
import math

import torch
import torch.nn as nn
from click.core import F
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.datasets as datasets
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt

input_path = "D:/Project 2/sentiment_analysis_eng/static/raw_data/GoodReads_Dataset_Raw.csv"

class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()

        # Define the convolutional layers
        self.conv1 = nn.Conv2d(3, 16, 3, padding=1)
        self.conv2 = nn.Conv2d(16, 32, 3, padding=1)
        self.conv3 = nn.Conv2d(32, 64, 3, padding=1)

        # Define the pooling layer
        self.pool = nn.MaxPool2d(2, 2)

        # Define the fully connected layers
        self.fc1 = nn.Linear(64 * 4 * 4, 500)
        self.fc2 = nn.Linear(500, 10)

        # Define the activation function
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.conv1(x)
        x = self.relu(x)
        x = self.pool(x)
        x = self.conv2(x)
        x = self.relu(x)
        x = self.pool(x)
        x = self.conv3(x)
        x = self.relu(x)
        x = self.pool(x)
        x = x.view(-1, 64 * 4 * 4)
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        return x

torch.manual_seed(123)

train_transform = transforms.Compose([
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

test_transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

train_dataset = datasets.MNIST(root="data/", train=True, transform=train_transform, download=True)
test_dataset = datasets.MNIST(root="data/", train=False, transform=test_transform, download=True)

train_loader = DataLoader(train_dataset, batch_size=128, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=128, shuffle=False)

class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=1, out_channels=16, kernel_size=5, stride=1, padding=2)
        self.conv2 = nn.Conv2d(in_channels=16, out_channels=32, kernel_size=5, stride=1, padding=2)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.fc1 = nn.Linear(in_features=32*7*7, out_features=120)
        self.fc2 = nn.Linear(in_features=120, out_features=10)

    def forward(self, x):
        x = self.conv1(x)
        x = nn.functional.relu(x)
        x = self.pool(x)
        x = self.conv2(x)
        x = nn.functional.relu(x)
        x = self.pool(x)
        x = x.view(-1, 32*7*7)
        x = self.fc1(x)
        x = nn.functional.relu(x)
        x = self.fc2(x)
        return x

model = CNN()

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

def train(model, device, train_loader, optimizer, epoch):
    model.train()
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = nn.functional.nll_loss(output, target)
        loss.backward()
        optimizer.step()
        if batch_idx % 100 == 0:
            print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                epoch, batch_idx * len(data), len(train_loader.dataset),
                100. * batch_idx / len(train_loader), loss.item()))
        for epoch in range(epochs):
            running_loss = 0.0
            for i, (inputs, labels) in enumerate(train_loader, 0):
                optimizer.zero_grad()
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

                running_loss += loss.item()

                if i % 100 == 99:
                    print(f"[Epoch {epoch + 1}, Batch {i + 1}] loss: {running_loss / 100:.3f}")
                    running_loss = 0.0

def test(model, device, test_loader):
    model.eval()
    test_loss = 0
    correct = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            test_loss += nn.functional.nll_loss(output, target, reduction='sum').item()
            pred = output.argmax(dim=1, keepdim=True)
            correct += pred.eq(target.view_as(pred)).sum().item()

    test_loss /= len(test_loader.dataset)

    print('\nTest set: Average loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
        test_loss, correct, len(test_loader.dataset),
        100. * correct / len(test_loader.dataset)))


batch_size = 64
epochs = 10
lr = 0.01


train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=batch_size, shuffle=False)


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = Net().to(device)
optimizer = optim.SGD(model.parameters(), lr=lr


plt.subplot(2,1,1)
plt.xlim(1,EPOCH_NUM)
plt.ylim(0.1,0.7)
xtick = np.arange(1,EPOCH_NUM+1,1)
plt.xticks(xtick)
plt.yticks()
ytick = np.arange(0.1,0.8,0.1)
plt.yticks(ytick)
plt.plot(x,loss_list,"red",label="Loss")
plt.plot(x, error_rate_list, "blue", label="Error Rate")
plt.legend()
plt.title("Loss & Error Rate")

plt.subplot(2,1,2)
plt.xlim(1,EPOCH_NUM)
plt.ylim(0.3,1)
xtick = np.arange(1,EPOCH_NUM+1,1)
plt.xticks(xtick)
plt.yticks()
ytick = np.arange(0.3,1.1,0.1)
plt.yticks(ytick)
plt.plot(x,accracy_list,"red",label="Accuracy")
plt.plot(x, precision_list, "blue", label="Precision")
plt.plot(x, recall_list, "yellow", label="Recall")
plt.plot(x, f1_score_list, "green", label="F1-score")
plt.legend()
plt.title("Performance")
plt.show()



plt.subplot(2,1,1)
plt.xlim(1,EPOCH_NUM)
plt.ylim(0.1,0.7)
xtick = np.arange(1,EPOCH_NUM+1,1)
plt.xticks(xtick)
plt.yticks()
ytick = np.arange(0.1,0.8,0.1)
plt.yticks(ytick)
plt.plot(x,loss,"red",label="Loss")
plt.plot(x, error, "blue", label="Error Rate")
plt.ylabel("Value")
plt.xlabel("Epoch")
plt.legend()
plt.title("Loss & Error Rate")

plt.subplot(2,1,2)
plt.xlim(1,EPOCH_NUM)
plt.ylim(0.3,1)
xtick = np.arange(1,EPOCH_NUM+1,1)
plt.xticks(xtick)
plt.yticks()
ytick = np.arange(0.3,1.1,0.1)
plt.yticks(ytick)
plt.plot(x,acc,"red",label="Accuracy")
plt.plot(x, pre, "blue", label="Precision")
plt.plot(x, recall, "yellow", label="Recall")
plt.plot(x, f1_score, "green", label="F1-score")
plt.legend()
plt.ylabel("Value")
plt.xlabel("Epoch")
plt.title("Performance")
plt.show()
