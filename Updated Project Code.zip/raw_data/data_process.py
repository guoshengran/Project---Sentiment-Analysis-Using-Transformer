import pandas as pd
from nltk.stem import WordNetLemmatizer

wnl = WordNetLemmatizer()
from nltk.tokenize import word_tokenize


def get_stop_words():
    """
    Obtain Stop Word List
    """
    with open("D:/Project 2/sentiment_analysis_eng/stopwords/english") as f:
        stopwords = f.readlines()
        stopwords = [word.strip() for word in stopwords]
    return stopwords


def normalise_text(text):
    """
    Process each row of data
    """
    stopwords = get_stop_words()
    text = text.lower()  # Convert to lower case
    text = text.replace(r"\#", "")  # replaces hashtags
    text = text.replace(r"http\S+", "URL")  # remove URL addresses
    text = text.replace(r"@", "")
    text = text.replace(r"[^A-Za-z0-9()!?\'\`\"]", " ")
    text = text.replace("\s{2,}", " ")
    text = word_tokenize(text)  # Word Segmentation
    text = [wnl.lemmatize(word) for word in text]  # Part of speech restore
    text = [word for word in text if word not in stopwords]  # remove stop words
    text = " ".join(text)
    return text


def trans_label(label):
    """
    label conversion
    """
    label_dic = {"__label__1": 0, "__label__2": 1}
    return label_dic[label]


if __name__ == "__main__":

    input_path = "/raw_data/GoodReads_Dataset_Raw.csv"
    output_path = "/raw_data/GoodReads_Dataset_Process.csv"
    train = pd.read_csv(input_path)
    train["text"] = train["text"].apply(normalise_text)
    train["label"] = train["label"].apply(trans_label)

    train.to_csv(output_path, sep="\t", index=False, encoding="utf_8", mode="w", header=True)
