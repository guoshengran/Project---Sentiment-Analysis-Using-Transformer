import time
import torch
import pandas as pd
from torchtext.data.utils import get_tokenizer
from torchtext.vocab import build_vocab_from_iterator
from torch.utils.data import DataLoader  # This module is mainly used to load data
from torch import nn

from torch.utils.data.dataset import random_split  # This module is used to split the training set test set verification set
from torchtext.data.functional import to_map_style_dataset

input_path = "D:/Project 2/sentiment_analysis_eng/raw_data/GoodReads_Dataset_Raw.csv"


class TextClassificationModel(nn.Module):
    """
    Model for text classification
    After words are embedded, they are all connected and then classified
    """

    def __init__(self, vocab_size, embed_dim, num_class):
        super(TextClassificationModel, self).__init__()
        self.embedding = nn.EmbeddingBag(vocab_size, embed_dim, sparse=True)
        # Linear link module of pythoch
        self.fc = nn.Linear(embed_dim, num_class)
        # Initialize weights that require gradient descent
        self.init_weights()

    def init_weights(self):
        # Scope of initialization of weight
        initrange = 0.5
        # Define the initialization distribution of the embedding layer
        self.embedding.weight.data.uniform_(-initrange, initrange)
        # Define the w weight initialization distribution of the full connection layer
        self.fc.weight.data.uniform_(-initrange, initrange)
        # Define the b (offset) weight initialization distribution of the full connection layer
        self.fc.bias.data.zero_()

    def forward(self, text, offsets):
        # The forward reasoning process of neural network
        embedded = self.embedding(text, offsets)
        # Return reasoning results
        return self.fc(embedded)


def yield_tokens(input_path):
    """
    generator iterator
    It is mainly to pass the sentence after word segmentation into the dictionary generator
    """
    # The function of the word breaker integrated in the word breaker torchtext is relatively powerful,
    # which can be seen from the source code_basic_english_normalize
    tokenizer = get_tokenizer("basic_english")
    # Read input sample
    all_sample = pd.read_csv(input_path)
    # Traverse the text column of the entire data
    for text in all_sample["text"]:
        # Generator generates data
        yield tokenizer(text)


# Changing from an iterator to a dictionary is mainly to record all words, and each word is given a number
vocab = build_vocab_from_iterator(yield_tokens(input_path), specials=["<unk>"])
# Set unknown words
vocab.set_default_index(vocab["<unk>"])

# Select gpu for training mode or use cpu when gpu is available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Number of categories
num_class = 2
# Length of dictionary
vocab_size = len(vocab)
# Dimension of embedded layer word vector
embed_dim = 16
# When initializing a model, the number of dictionary quantifiers, vector dimensions, and categories are specified
model = TextClassificationModel(vocab_size, embed_dim, num_class).to(device)
# Hyperparameter
# epoch
EPOCHS = 50
# learning rate
LR = 0.001
# batch size for training =
BATCH_SIZE = 128

# Loss function cross quotient loss function
criterion = torch.nn.CrossEntropyLoss()
# Selection of optimizer
optimizer = torch.optim.SGD(model.parameters(), lr=LR)
# The learning rate decays. The learning rate will decrease when the model converges quickly
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, 1.0, gamma=0.1)


def train(dataloader):

    # Training mode when setting model
    model.train()
    # Initialize the exact number of forecasts and the number of all samples
    total_acc, total_count = 0, 0
    # Print rounds, and print the results every few samples
    log_interval = 500
    # Start time
    start_time = time.time()

    # Traverse all samples
    for idx, (label, text, offsets) in enumerate(dataloader):
        """
        label: Specific label of each sample
        text: The index in the batch is concatenated into a vector
        offsers: Position of each sentence in the batch
        """
        # Emptying gradient
        optimizer.zero_grad()
        # The model predicts the sample
        predicted_label = model(text, offsets)
        # Calculate loss value
        loss = criterion(predicted_label, label)
        # The calculation of gradient records the gradient of all x that need gradient descen
        loss.backward()
        # A method of gradient truncation to prevent gradient explosion from disappearing
        torch.nn.utils.clip_grad_norm_(model.parameters(), 0.1)
        # The real place to update x according to the gradient  x = x-lr * x.grad
        optimizer.step()
        # Calculate the number of samples predicted by the model
        total_acc += (predicted_label.argmax(1) == label).sum().item()
        # Number of all samples
        total_count += label.size(0)
        # How many samples to print the results
        if idx % log_interval == 0 and idx > 0:
            # Calculate the time to train once
            elapsed = time.time() - start_time
            # Time spent printing the length of index data of epoch specific samples to calculate the accuracy rate
            print(
                "| epoch {:3d} | {:5d}/{:5d} batches | accuracy {:8.3f} ｜ cost {}s".format(
                    epoch, idx, len(dataloader), total_acc / total_count, elapsed
                )
            )
            # Clear the exact number and all the numbers
            total_acc, total_count = 0, 0
            # Reassign start time
            start_time = time.time()


def evaluate(dataloader):


    # Evaluate mode when setting model
    model.eval()
    # Initialize the exact number of forecasts and the number of all samples
    total_acc, total_count = 0, 0
    # The explanation here is only to evaluate the gradient decline
    with torch.no_grad():
        for idx, (label, text, offsets) in enumerate(dataloader):
            # Use the model to predict the evaluation data
            predicted_label = model(text, offsets)
            # This sentence only calculates loss and is not used. It can be ignored
            loss = criterion(predicted_label, label)
            # Count the correct quantity predicted
            total_acc += (predicted_label.argmax(1) == label).sum().item()
            # Count the number of all evaluation samples
            total_count += label.size(0)
    # Return model prediction accuracy
    return total_acc / total_count


# Select a specific word breaker
tokenizer = get_tokenizer("basic_english")

text_pipeline = lambda x: vocab(tokenizer(x))


def trans_label(label):
    """
    label数据转换
    """
    label_dic = {"__label__1": 0, "__label__2": 1}
    return label_dic[label]


def collate_batch(batch):
    """
    Create input model data
    """
    # Initialize the list of the tag text data and the list of the specific location of the recorded text word
    label_list, text_list, offsets = [], [], [0]
    # Traverse the value of a batch to get the label and text
    for (_text, _label) in batch:
        # Splice the label on the label_ In list
        label_list.append(trans_label(_label))
        # Use text for words of text data_ The pipeline method first converts to index,
        # that is, a word and a number, and then changes the number to Tensor
        processed_text = torch.tensor(text_pipeline(_text), dtype=torch.int64)
        # Change the processed text words into numbers and tensor, and then splice and save them
        text_list.append(processed_text)
        # Record the length of each sentence word
        offsets.append(processed_text.size(0))
    label_list = torch.tensor(label_list, dtype=torch.int64)
    offsets = torch.tensor(offsets[:-1]).cumsum(dim=0)
    text_list = torch.cat(text_list)
    # Allocate the constructed tensor to the corresponding devices
    return label_list.to(device), text_list.to(device), offsets.to(device)


def yield_dataset():
    """
    Generate iterators for all data
    """
    all_sample = pd.read_csv(input_path)
    text = all_sample["text"]
    label = all_sample["label"]
    for index in range(len(all_sample["text"])):
        yield (text[index], label[index])


# Change iterator data to mapping type data because the format of data sent into the model requires the framework requirements
all_dataset = to_map_style_dataset(yield_dataset())
# Data segmentation, training machine, verification set, test set
train_data, valid_data, test_data = random_split(all_dataset, [0.8, 0.1, 0.1])

# Build classes that generate training data into the model
train_dataloader = DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=True, collate_fn=collate_batch)
# Build a class that generates validation data into the model
valid_dataloader = DataLoader(valid_data, batch_size=BATCH_SIZE, shuffle=True, collate_fn=collate_batch)
# Build classes that generate test data into the model
test_dataloader = DataLoader(test_data, batch_size=BATCH_SIZE, shuffle=True, collate_fn=collate_batch)


#Total accuracy saved
total_accu = None
for epoch in range(1, EPOCHS + 1):
    # record start time
    epoch_start_time = time.time()
    train(train_dataloader)
    accu_val = evaluate(valid_dataloader)
    # Judge whether the accuracy variable exists.
    # When the global accuracy is less than the evaluation accuracy of this batch, use scheduler.step() to adjust the lr
    if total_accu is not None and total_accu > accu_val:
        scheduler.step()
    else:
        # Update global accuracy
        total_accu = accu_val
    print("-" * 59)
    print(
        "| end of epoch {:3d} | time: {:5.2f}s | "
        "valid accuracy {:8.3f} ".format(epoch, time.time() - epoch_start_time, accu_val)
    )
    print("-" * 59)

print("Checking the results of test dataset.")
accu_test = evaluate(test_dataloader)
print("test accuracy {:8.3f}".format(accu_test))
