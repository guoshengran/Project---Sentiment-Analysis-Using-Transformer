### 英文情感分析


需要下载


+ 国内的镜像源下载包
```
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple torch==1.13.0
```
+ 装指定文件夹里的所有包
```
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r .\requirements.txt
```